import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { Router, type IRouter } from "express";

const router: IRouter = Router();
const apkPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../../../generated-artifacts/WePlay-AutoDraw-debug.apk",
);

router.get("/downloads/weplay-autodraw.apk", (_req, res, next) => {
  if (!existsSync(apkPath)) {
    res.status(404).type("text/plain").send("The WePlay AutoDraw APK has not been built yet.");
    return;
  }

  res.type("application/vnd.android.package-archive");
  res.download(apkPath, "WePlay-AutoDraw-debug.apk", (error) => {
    if (error && !res.headersSent) next(error);
  });
});

export default router;

package app.weplay.autodraw

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.max

/**
 * Creates a one-bit edge drawing. Gray values are used only internally while
 * measuring gradients; every output pixel is pure black or pure white.
 */
object EdgeProcessor {
    const val MAX_EDGE = 720

    fun prepare(source: Bitmap): Bitmap {
        val factor = minOf(1f, MAX_EDGE.toFloat() / max(source.width, source.height))
        if (factor >= 1f) return source.copy(Bitmap.Config.ARGB_8888, false)
        return Bitmap.createScaledBitmap(
            source,
            (source.width * factor).toInt().coerceAtLeast(1),
            (source.height * factor).toInt().coerceAtLeast(1),
            true,
        )
    }

    fun render(
        source: Bitmap,
        threshold: Int,
        faceContours: List<List<PointF>>,
    ): Bitmap {
        val width = source.width
        val height = source.height
        val input = IntArray(width * height)
        source.getPixels(input, 0, width, 0, 0, width, height)

        val gray = IntArray(input.size)
        for (i in input.indices) {
            val color = input[i]
            gray[i] =
                (77 * Color.red(color) + 150 * Color.green(color) + 29 * Color.blue(color)) shr 8
        }

        // A small Gaussian-like blur suppresses camera noise without filling shadows.
        val smooth = blur(gray, width, height)
        val magnitude = IntArray(input.size)
        val high = threshold.coerceIn(35, 300)
        val low = (high * 0.48f).toInt()
        val edge = BooleanArray(input.size)
        val queue = IntArray(input.size)
        var tail = 0

        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val i = y * width + x
                val gx =
                    -smooth[i - width - 1] - 2 * smooth[i - 1] - smooth[i + width - 1] +
                        smooth[i - width + 1] + 2 * smooth[i + 1] + smooth[i + width + 1]
                val gy =
                    -smooth[i - width - 1] - 2 * smooth[i - width] - smooth[i - width + 1] +
                        smooth[i + width - 1] + 2 * smooth[i + width] + smooth[i + width + 1]
                val strength = abs(gx) + abs(gy)
                magnitude[i] = strength
                if (strength >= high) {
                    edge[i] = true
                    queue[tail++] = i
                }
            }
        }

        // Hysteresis keeps weaker edge pixels only when connected to a strong edge.
        var head = 0
        while (head < tail) {
            val index = queue[head++]
            val x = index % width
            val y = index / width
            for (dy in -1..1) {
                for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx
                    val ny = y + dy
                    if (nx !in 1 until width - 1 || ny !in 1 until height - 1) continue
                    val neighbor = ny * width + nx
                    if (!edge[neighbor] && magnitude[neighbor] >= low) {
                        edge[neighbor] = true
                        queue[tail++] = neighbor
                    }
                }
            }
        }

        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(input.size) { i -> if (edge[i]) Color.BLACK else Color.WHITE }
        output.setPixels(pixels, 0, width, 0, 0, width, height)

        // ML Kit contributes facial landmarks and inner contours: eyes, brows,
        // nose, lips and face outline. Hair and other image details come from edges.
        if (faceContours.isNotEmpty()) {
            val canvas = Canvas(output)
            val paint =
                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.BLACK
                    style = Paint.Style.STROKE
                    strokeWidth = 2.2f
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
            for (contour in faceContours) {
                if (contour.size < 2) continue
                for (i in 0 until contour.lastIndex) {
                    canvas.drawLine(
                        contour[i].x,
                        contour[i].y,
                        contour[i + 1].x,
                        contour[i + 1].y,
                        paint,
                    )
                }
            }
            // Re-binarize antialiased contour strokes so the final bitmap has no gray.
            output.getPixels(pixels, 0, width, 0, 0, width, height)
            for (i in pixels.indices) {
                val color = pixels[i]
                val darkness = (Color.red(color) + Color.green(color) + Color.blue(color)) / 3
                pixels[i] = if (darkness < 235) Color.BLACK else Color.WHITE
            }
            output.setPixels(pixels, 0, width, 0, 0, width, height)
        }
        return output
    }

    private fun blur(source: IntArray, width: Int, height: Int): IntArray {
        val result = source.copyOf()
        val weights = intArrayOf(1, 2, 1)
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                var sum = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        sum += source[(y + dy) * width + x + dx] * weights[dy + 1] * weights[dx + 1]
                    }
                }
                result[y * width + x] = sum / 16
            }
        }
        return result
    }
}

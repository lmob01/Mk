package app.weplay.autodraw

/** Idempotent selection confirmation state, independent of transient window events. */
internal class AreaSelectionState {
    enum class Confirmation {
        CONFIRMED,
        ALREADY_CONFIRMED,
        WAIT_FOR_TARGET,
        STALE,
        NOT_SELECTING,
    }

    private var generation = 0
    var isSelecting = false
        private set
    var isConfirmed = false
        private set

    fun begin(): Int {
        generation += 1
        isSelecting = true
        isConfirmed = false
        return generation
    }

    fun confirm(token: Int, targetIsForeground: Boolean): Confirmation {
        if (token != generation) return Confirmation.STALE
        if (isConfirmed) return Confirmation.ALREADY_CONFIRMED
        if (!isSelecting) return Confirmation.NOT_SELECTING
        if (!targetIsForeground) return Confirmation.WAIT_FOR_TARGET
        isSelecting = false
        isConfirmed = true
        return Confirmation.CONFIRMED
    }

    fun reset() {
        generation += 1
        isSelecting = false
        isConfirmed = false
    }
}

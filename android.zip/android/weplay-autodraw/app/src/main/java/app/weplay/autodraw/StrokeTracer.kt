package app.weplay.autodraw

import android.graphics.Bitmap
import android.graphics.PointF

/** Converts black connected edge pixels into ordered, open hand-drawing paths. */
object StrokeTracer {
    private const val MAX_STROKES = 6000

    fun extract(bitmap: Bitmap): List<DrawStroke> {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val black = BooleanArray(pixels.size) { pixels[it] == android.graphics.Color.BLACK }
        val seen = BooleanArray(pixels.size)
        val queue = IntArray(pixels.size)
        val paths = ArrayList<DrawStroke>()

        for (seed in black.indices) {
            if (!black[seed] || seen[seed]) continue
            var read = 0
            var write = 0
            queue[write++] = seed
            seen[seed] = true
            val component = ArrayList<Int>()

            while (read < write) {
                val current = queue[read++]
                component.add(current)
                val x = current % width
                val y = current / width
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val nx = x + dx
                        val ny = y + dy
                        if (nx !in 0 until width || ny !in 0 until height) continue
                        val next = ny * width + nx
                        if (black[next] && !seen[next]) {
                            seen[next] = true
                            queue[write++] = next
                        }
                    }
                }
            }

            if (component.size < 4) continue
            val membership = BooleanArray(pixels.size)
            component.forEach { membership[it] = true }
            val adjacency = HashMap<Int, MutableList<Int>>(component.size)
            for (point in component) {
                val x = point % width
                val y = point / width
                val neighbors = ArrayList<Int>(8)
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val nx = x + dx
                        val ny = y + dy
                        if (nx in 0 until width && ny in 0 until height) {
                            val candidate = ny * width + nx
                            if (!membership[candidate]) continue
                            // A diagonal edge between pixels is redundant when an
                            // orthogonal neighbor already connects the same corner.
                            if (dx != 0 && dy != 0) {
                                val horizontal = y * width + nx
                                val vertical = ny * width + x
                                if (membership[horizontal] || membership[vertical]) continue
                            }
                            neighbors.add(candidate)
                        }
                    }
                }
                adjacency[point] = neighbors
            }

            val usedEdges = HashSet<Long>()
            fun walk(start: Int, first: Int) {
                if (paths.size >= MAX_STROKES) return
                val chain = ArrayList<Int>()
                chain.add(start)
                var previous = start
                var current = first
                usedEdges.add(edgeKey(previous, current))
                chain.add(current)

                while (current != start) {
                    val candidates =
                        adjacency[current].orEmpty().filter {
                            edgeKey(current, it) !in usedEdges
                        }
                    if (candidates.isEmpty()) break

                    val previousX = previous % width
                    val previousY = previous / width
                    val currentX = current % width
                    val currentY = current / width
                    val directionX = currentX - previousX
                    val directionY = currentY - previousY
                    val next =
                        candidates.maxBy { candidate ->
                            val candidateX = candidate % width
                            val candidateY = candidate / width
                            val nextX = candidateX - currentX
                            val nextY = candidateY - currentY
                            // Prefer continuing in the same direction at branches.
                            (directionX * nextX + directionY * nextY).toFloat() /
                                kotlin.math.sqrt(
                                    (directionX * directionX + directionY * directionY).toFloat() *
                                        (nextX * nextX + nextY * nextY).toFloat(),
                                )
                        }
                    previous = current
                    current = next
                    usedEdges.add(edgeKey(previous, current))
                    chain.add(current)
                }

                val simplified = simplify(chain, width, height)
                if (simplified.size >= 2 && lengthInPixels(simplified, width, height) >= 3f) {
                    paths.add(DrawStroke(simplified))
                }
            }

            // Start at endpoints and junctions first so branches become separate strokes.
            for (point in component) {
                if (adjacency[point].orEmpty().size == 2) continue
                for (neighbor in adjacency[point].orEmpty()) {
                    if (edgeKey(point, neighbor) !in usedEdges) walk(point, neighbor)
                }
            }
            // Closed loops have no endpoints; start each remaining loop at any unused edge.
            for (point in component) {
                for (neighbor in adjacency[point].orEmpty()) {
                    if (edgeKey(point, neighbor) !in usedEdges) walk(point, neighbor)
                }
            }
            if (paths.size >= MAX_STROKES) break
        }
        return paths
    }

    private fun simplify(indices: List<Int>, width: Int, height: Int): List<PointF> {
        if (indices.size <= 2) {
            return indices.map { PointF((it % width).toFloat() / width, (it / width).toFloat() / height) }
        }
        val result = ArrayList<PointF>()
        result.add(PointF((indices.first() % width).toFloat() / width, (indices.first() / width).toFloat() / height))
        var lastDirectionX = 0
        var lastDirectionY = 0
        for (i in 1 until indices.lastIndex) {
            val previous = indices[i - 1]
            val current = indices[i]
            val next = indices[i + 1]
            val directionX = (current % width) - (previous % width)
            val directionY = (current / width) - (previous / width)
            val nextX = (next % width) - (current % width)
            val nextY = (next / width) - (current / width)
            if (directionX != nextX || directionY != nextY ||
                (lastDirectionX != 0 && directionX != lastDirectionX) ||
                (lastDirectionY != 0 && directionY != lastDirectionY)
            ) {
                result.add(PointF((current % width).toFloat() / width, (current / width).toFloat() / height))
            }
            lastDirectionX = nextX
            lastDirectionY = nextY
        }
        val last = indices.last()
        result.add(PointF((last % width).toFloat() / width, (last / width).toFloat() / height))
        return result
    }

    private fun edgeKey(a: Int, b: Int): Long {
        val low = minOf(a, b)
        val high = maxOf(a, b)
        return (low.toLong() shl 32) or (high.toLong() and 0xffffffffL)
    }

    private fun lengthInPixels(points: List<PointF>, width: Int, height: Int): Float {
        var length = 0f
        for (index in 1 until points.size) {
            val dx = (points[index].x - points[index - 1].x) * width
            val dy = (points[index].y - points[index - 1].y) * height
            length += kotlin.math.sqrt(dx * dx + dy * dy)
        }
        return length
    }
}

data class DrawStroke(val points: List<PointF>)

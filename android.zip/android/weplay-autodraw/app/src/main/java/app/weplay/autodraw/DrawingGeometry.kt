package app.weplay.autodraw

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

internal data class ScreenRect(
    val left: Int,
    val top: Int,
    val width: Int,
    val height: Int,
) {
    init {
        require(left >= 0 && top >= 0 && width > 0 && height > 0)
    }
}

internal data class NormalizedRect(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
) {
    fun toScreenRect(screenWidth: Int, screenHeight: Int): ScreenRect {
        require(screenWidth > 0 && screenHeight > 0)
        val safeLeft = left.coerceIn(0f, 1f)
        val safeTop = top.coerceIn(0f, 1f)
        val leftPx = (safeLeft * screenWidth).roundToInt().coerceIn(0, screenWidth - 1)
        val topPx = (safeTop * screenHeight).roundToInt().coerceIn(0, screenHeight - 1)
        val rightPx =
            ((safeLeft + width.coerceIn(0f, 1f)) * screenWidth)
                .roundToInt()
                .coerceIn(leftPx + 1, screenWidth)
        val bottomPx =
            ((safeTop + height.coerceIn(0f, 1f)) * screenHeight)
                .roundToInt()
                .coerceIn(topPx + 1, screenHeight)
        return ScreenRect(leftPx, topPx, rightPx - leftPx, bottomPx - topPx)
    }

    companion object {
        fun fromScreenRect(rect: ScreenRect, screenWidth: Int, screenHeight: Int): NormalizedRect {
            require(screenWidth > 0 && screenHeight > 0)
            require(rect.left + rect.width <= screenWidth)
            require(rect.top + rect.height <= screenHeight)
            return NormalizedRect(
                rect.left.toFloat() / screenWidth,
                rect.top.toFloat() / screenHeight,
                rect.width.toFloat() / screenWidth,
                rect.height.toFloat() / screenHeight,
            )
        }
    }
}

internal data class FloatRect(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
)

internal data class ScreenPoint(val x: Float, val y: Float)

internal data class DrawingTransform(
    val area: ScreenRect,
    val drawingBounds: FloatRect,
    val screenWidth: Int,
    val screenHeight: Int,
) {
    fun map(normalizedX: Float, normalizedY: Float): ScreenPoint {
        val maxX = (area.left + area.width - 1).toFloat()
        val maxY = (area.top + area.height - 1).toFloat()
        return ScreenPoint(
            (drawingBounds.left + normalizedX.coerceIn(0f, 1f) * drawingBounds.width)
                .coerceIn(area.left.toFloat(), maxX),
            (drawingBounds.top + normalizedY.coerceIn(0f, 1f) * drawingBounds.height)
                .coerceIn(area.top.toFloat(), maxY),
        )
    }
}

internal object DrawingGeometry {
    fun fit(
        sourceWidth: Int,
        sourceHeight: Int,
        area: ScreenRect,
        screenWidth: Int,
        screenHeight: Int,
        sizeScale: Float,
        horizontalOffset: Float,
        verticalOffset: Float,
    ): DrawingTransform {
        require(sourceWidth > 0 && sourceHeight > 0)
        require(screenWidth > 0 && screenHeight > 0)
        require(area.left + area.width <= screenWidth)
        require(area.top + area.height <= screenHeight)

        val fitScale =
            min(
                area.width.toFloat() / sourceWidth,
                area.height.toFloat() / sourceHeight,
            )
        val scale = fitScale * sizeScale.coerceIn(0.1f, 1f)
        val drawWidth = sourceWidth * scale
        val drawHeight = sourceHeight * scale
        val freeX = max(0f, area.width - drawWidth)
        val freeY = max(0f, area.height - drawHeight)
        val left =
            area.left + freeX / 2f + freeX * horizontalOffset.coerceIn(-0.4f, 0.4f)
        val top =
            area.top + freeY / 2f + freeY * verticalOffset.coerceIn(-0.4f, 0.4f)
        return DrawingTransform(
            area,
            FloatRect(left, top, drawWidth, drawHeight),
            screenWidth,
            screenHeight,
        )
    }
}

package app.weplay.autodraw

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.accessibility.AccessibilityEvent
import android.view.WindowManager
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View

/**
 * User-enabled Android Accessibility Service. It does not inspect screen content.
 * It waits for the package explicitly selected as WePlay, then requires one more
 * tap on the floating control after the user opens WePlay's drawing screen.
 */
class DrawAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val strokes = ArrayDeque<DrawStroke>()
    private val selectionState = AreaSelectionState()
    private val areaPreferences by lazy { getSharedPreferences(AREA_PREFERENCES, MODE_PRIVATE) }
    private var targetPackage: String? = null
    private var activePackage: String? = null
    private var waitingForTarget = false
    private var targetReady = false
    private var isDrawing = false
    private var runToken = 0
    private var selectionToken = 0
    private var totalGestureCount = 0
    private var completedGestureCount = 0
    private var dispatchedGestureCount = 0
    private var imageWidth = 1
    private var imageHeight = 1
    private var sizeScale = 1f
    private var horizontalOffset = 0f
    private var verticalOffset = 0f
    private var speed = 1f
    private var areaLeft = 0
    private var areaTop = 0
    private var areaWidth = 1
    private var areaHeight = 1
    private var selectionScreenWidth = 0
    private var selectionScreenHeight = 0
    private var normalizedArea: NormalizedRect? = null
    private var drawingTransform: DrawingTransform? = null
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var overlayStatus: TextView? = null
    private var overlayButton: Button? = null
    private var overlayAttached = false
    private var areaSelectionOverlay: AreaSelectionOverlay? = null
    val hasActiveSession: Boolean
        get() = waitingForTarget || targetReady || selectionState.isSelecting || isDrawing

    private val waitTimeout = Runnable {
        stopDrawing("لم يتم فتح WePlay قبل انتهاء المهلة.")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        Log.i(TAG, "Accessibility service connected; gesture dispatch enabled by user.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event?.packageName?.toString() ?: return
        if (isOwnOverlayEvent(packageName)) {
            Log.v(TAG, "Ignoring our accessibility overlay window event.")
            return
        }
        val previousPackage = activePackage
        activePackage = packageName
        Log.d(
            TAG,
            "Window changed: $previousPackage -> $packageName; waiting=$waitingForTarget, " +
                "selecting=${selectionState.isSelecting}, confirmed=${selectionState.isConfirmed}, drawing=$isDrawing",
        )

        if (isDrawing && packageName != targetPackage) {
            stopDrawing("توقف الرسم لأن WePlay لم تعد في الواجهة.")
            return
        }
        if (waitingForTarget && packageName == targetPackage) {
            waitingForTarget = false
            targetReady = true
            handler.removeCallbacks(waitTimeout)
            updateOverlay(
                "افتح صفحة الرسم في WePlay ثم اضغط تحديد المساحة.",
                "تحديد مساحة الرسم",
                ::beginAreaSelection,
            )
            return
        }
        if (packageName == targetPackage) {
            when {
                selectionState.isSelecting -> {
                    updateOverlay(
                        "عاد WePlay. الإطار محفوظ؛ اضغط اعتماد المساحة.",
                        "اعتماد المساحة",
                        { confirmAreaSelection(selectionToken) },
                    )
                }
                targetReady && selectionState.isConfirmed -> {
                    updateOverlay(
                        "المساحة محفوظة. ابدأ عندما تكون لوحة الرسم جاهزة.",
                        "ابدأ الرسم",
                        ::beginDispatch,
                    )
                }
                !isDrawing -> {
                    targetReady = true
                    updateOverlay(
                        "WePlay مفتوح. انتقل إلى لوحة الرسم ثم حدّد المساحة.",
                        "تحديد مساحة الرسم",
                        ::beginAreaSelection,
                    )
                }
            }
        } else if (selectionState.isSelecting) {
            updateOverlay(
                "عد إلى WePlay؛ الإطار لم يُحذف ويمكن اعتماده هناك.",
                "اعتماد المساحة",
                { confirmAreaSelection(selectionToken) },
            )
        } else if (targetReady && selectionState.isConfirmed) {
            updateOverlay(
                "عد إلى WePlay؛ المساحة المحددة محفوظة.",
                "ابدأ الرسم",
                ::beginDispatch,
            )
        }
    }

    private fun isOwnOverlayEvent(packageName: String): Boolean =
        packageName == this.packageName &&
            !MainActivity.isInForeground &&
            (overlayAttached || areaSelectionOverlay != null)

    override fun onInterrupt() {
        stopDrawing("تم إيقاف خدمة اللمس.")
    }

    fun startDrawing(
        sourceStrokes: List<DrawStroke>,
        selectedPackage: String,
        sourceWidth: Int,
        sourceHeight: Int,
        scale: Float,
        xOffset: Float,
        yOffset: Float,
        speedMultiplier: Float,
    ) {
        stopDrawing(null)
        if (sourceStrokes.isEmpty()) {
            showToast("لم يتم العثور على خطوط قابلة للرسم.")
            return
        }
        strokes.addAll(sourceStrokes)
        totalGestureCount = sourceStrokes.size
        completedGestureCount = 0
        dispatchedGestureCount = 0
        targetPackage = selectedPackage
        imageWidth = sourceWidth.coerceAtLeast(1)
        imageHeight = sourceHeight.coerceAtLeast(1)
        sizeScale = scale.coerceIn(0.35f, 1f)
        horizontalOffset = xOffset.coerceIn(-0.4f, 0.4f)
        verticalOffset = yOffset.coerceIn(-0.4f, 0.4f)
        speed = speedMultiplier.coerceIn(1f, 5f)
        waitingForTarget = true
        targetReady = false
        isDrawing = false
        normalizedArea = loadSavedArea()
        drawingTransform = null
        runToken++
        Log.i(
            TAG,
            "Session started: target=$selectedPackage, image=${imageWidth}x$imageHeight, " +
                "strokes=${sourceStrokes.size}, size=$sizeScale, offset=($horizontalOffset,$verticalOffset), speed=$speed",
        )
        handler.postDelayed(waitTimeout, 120_000L)
        showControlOverlay(
            "افتح WePlay وانتقل إلى صفحة الرسم.",
            "إلغاء",
            ::cancelWaiting,
        )
        showToast("افتح صفحة الرسم في WePlay، ثم حدّد مساحة اللوحة من الإطار الأخضر.")
    }

    private fun cancelWaiting() {
        stopDrawing("تم إلغاء الانتظار.")
    }

    private fun beginAreaSelection() {
        if (activePackage != targetPackage) {
            updateOverlay(
                "عد إلى صفحة الرسم في WePlay؛ لن تُفقد مساحة الرسم.",
                "تحديد مساحة الرسم",
                ::beginAreaSelection,
            )
            return
        }
        if (!targetReady) {
            Log.w(TAG, "Area selection requested before the target window was confirmed.")
            updateOverlay(
                "انتظر ظهور صفحة WePlay ثم حاول تحديد المساحة.",
                "تحديد مساحة الرسم",
                ::beginAreaSelection,
            )
            return
        }
        val manager = windowManager
        if (manager == null) {
            Log.e(TAG, "Cannot select area because WindowManager is unavailable.")
            stopDrawing("تعذر عرض إطار تحديد مساحة الرسم.")
            return
        }
        removeAreaOverlay()

        val (screenWidth, screenHeight) = screenSize()
        selectionScreenWidth = screenWidth
        selectionScreenHeight = screenHeight
        normalizedArea = loadSavedArea(screenWidth, screenHeight)
        val savedArea = normalizedArea?.toScreenRect(screenWidth, screenHeight)
        val restoredPreviousArea = savedArea != null
        if (savedArea != null) {
            areaLeft = savedArea.left
            areaTop = savedArea.top
            areaWidth = savedArea.width
            areaHeight = savedArea.height
        } else {
            areaWidth = (screenWidth * 0.82f).toInt().coerceIn(1, screenWidth)
            areaHeight = (screenHeight * 0.64f).toInt().coerceIn(1, screenHeight)
            areaLeft = ((screenWidth - areaWidth) / 2).coerceAtLeast(0)
            areaTop = ((screenHeight - areaHeight) / 2).coerceAtLeast(0)
        }
        val token = selectionState.begin()
        selectionToken = token
        val selectionView =
            AreaSelectionOverlay(
                context = this,
                screenWidth = screenWidth,
                screenHeight = screenHeight,
                onBoundsChanged = { left, top, selectedWidth, selectedHeight ->
                    areaLeft = left
                    areaTop = top
                    areaWidth = selectedWidth
                    areaHeight = selectedHeight
                },
                onConfirm = { handler.post { confirmAreaSelection(token) } },
                onWindowFailure = { error ->
                    Log.e(TAG, "Unable to move or resize the selection frame.", error)
                    showToast("تعذر تحديث الإطار. بقيت آخر إحداثيات صالحة محفوظة.")
                },
            )
        val params =
            WindowManager.LayoutParams(
                areaWidth,
                areaHeight,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = areaLeft
                y = areaTop
            }
        try {
            manager.addView(selectionView, params)
            selectionView.attach(manager, params)
            areaSelectionOverlay = selectionView
            targetReady = false
            Log.i(
                TAG,
                "Selection frame shown: screen=${screenWidth}x$screenHeight, " +
                    "area=($areaLeft,$areaTop ${areaWidth}x$areaHeight), density=${resources.displayMetrics.density}",
            )
            updateOverlay(
                if (restoredPreviousArea) {
                    "ظهرت آخر مساحة محفوظة؛ عدّل الإطار أو اعتمده."
                } else {
                    "حرّك الإطار فوق لوحة الرسم؛ اسحب زاويته لتغيير حجمه."
                },
                "اعتماد المساحة",
                { confirmAreaSelection(token) },
            )
        } catch (error: Exception) {
            Log.e(TAG, "Unable to add the selection frame window.", error)
            removeAreaOverlay()
            targetReady = true
            selectionState.reset()
            showToast("تعذر عرض إطار تحديد مساحة الرسم: ${error.localizedMessage ?: "خطأ نافذة Android"}")
        }
    }

    private fun confirmAreaSelection(token: Int) {
        val (currentScreenWidth, currentScreenHeight) = screenSize()
        if (selectionState.isSelecting &&
            (currentScreenWidth != selectionScreenWidth || currentScreenHeight != selectionScreenHeight)
        ) {
            Log.w(
                TAG,
                "Selection confirmation rejected after display size changed: " +
                    "${selectionScreenWidth}x$selectionScreenHeight -> ${currentScreenWidth}x$currentScreenHeight",
            )
            removeAreaOverlay()
            selectionState.reset()
            targetReady = activePackage == targetPackage
            updateOverlay(
                "تغيّر اتجاه الشاشة أو حجمها؛ أُعيد ضبط الإطار. حدّد المساحة من جديد.",
                "تحديد مساحة الرسم",
                ::beginAreaSelection,
            )
            return
        }
        when (val result = selectionState.confirm(token, activePackage == targetPackage)) {
            AreaSelectionState.Confirmation.CONFIRMED -> {
                targetReady = true
                val screenWidth = currentScreenWidth
                val screenHeight = currentScreenHeight
                areaLeft = areaLeft.coerceIn(0, screenWidth - 1)
                areaTop = areaTop.coerceIn(0, screenHeight - 1)
                areaWidth = areaWidth.coerceIn(1, screenWidth - areaLeft)
                areaHeight = areaHeight.coerceIn(1, screenHeight - areaTop)
                val confirmedArea =
                    NormalizedRect.fromScreenRect(
                        ScreenRect(areaLeft, areaTop, areaWidth, areaHeight),
                        screenWidth,
                        screenHeight,
                    )
                normalizedArea = confirmedArea
                saveArea(confirmedArea, screenWidth, screenHeight)
                Log.i(
                    TAG,
                    "Area confirmed: screen=${screenWidth}x$screenHeight, " +
                        "area=($areaLeft,$areaTop ${areaWidth}x$areaHeight), normalized=$normalizedArea",
                )
                removeAreaOverlay()
                showConfirmedAreaStatus()
            }
            AreaSelectionState.Confirmation.ALREADY_CONFIRMED -> {
                Log.i(TAG, "Duplicate confirmation ignored; keeping the confirmed area.")
                targetReady = true
                removeAreaOverlay()
                showConfirmedAreaStatus()
            }
            AreaSelectionState.Confirmation.WAIT_FOR_TARGET -> {
                Log.w(
                    TAG,
                    "Confirmation deferred: active=$activePackage target=$targetPackage; preserving selection frame.",
                )
                updateOverlay(
                    "عد إلى WePlay أولًا؛ الإطار وإحداثياته محفوظة.",
                    "اعتماد المساحة",
                    { confirmAreaSelection(token) },
                )
            }
            AreaSelectionState.Confirmation.STALE,
            AreaSelectionState.Confirmation.NOT_SELECTING,
            -> {
                Log.w(TAG, "Ignoring invalid confirmation: token=$token state=$result.")
                if (selectionState.isConfirmed) {
                    targetReady = true
                    removeAreaOverlay()
                    showConfirmedAreaStatus()
                } else if (targetPackage != null) {
                    targetReady = activePackage == targetPackage
                    updateOverlay(
                        "لم تُعتمد المساحة بعد. حرّك الإطار ثم اعتمده.",
                        "تحديد مساحة الرسم",
                        ::beginAreaSelection,
                    )
                }
            }
        }
    }

    private fun showConfirmedAreaStatus() {
        updateOverlay(
            "المساحة ${areaWidth}×${areaHeight} محفوظة. ابدأ عندما تكون لوحة الرسم جاهزة.",
            "ابدأ الرسم",
            ::beginDispatch,
        )
    }

    private fun loadSavedArea(): NormalizedRect? {
        val (screenWidth, screenHeight) = screenSize()
        return loadSavedArea(screenWidth, screenHeight)
    }

    private fun loadSavedArea(screenWidth: Int, screenHeight: Int): NormalizedRect? {
        val landscape = screenWidth >= screenHeight
        if (!areaPreferences.contains(KEY_AREA_LEFT)) return null
        if (areaPreferences.getBoolean(KEY_AREA_LANDSCAPE, landscape) != landscape) {
            Log.i(TAG, "Saved drawing area belongs to the other screen orientation; requesting calibration.")
            return null
        }
        val currentAspect = screenWidth.toFloat() / screenHeight
        val savedAspect = areaPreferences.getFloat(KEY_AREA_ASPECT, currentAspect)
        if (!savedAspect.isFinite() || kotlin.math.abs(savedAspect / currentAspect - 1f) > 0.05f) {
            Log.i(TAG, "Saved drawing area aspect ratio differs; requesting calibration.")
            return null
        }
        val left = areaPreferences.getFloat(KEY_AREA_LEFT, Float.NaN)
        val top = areaPreferences.getFloat(KEY_AREA_TOP, Float.NaN)
        val width = areaPreferences.getFloat(KEY_AREA_WIDTH, Float.NaN)
        val height = areaPreferences.getFloat(KEY_AREA_HEIGHT, Float.NaN)
        if (!left.isFinite() || !top.isFinite() || !width.isFinite() || !height.isFinite() ||
            width <= 0f || height <= 0f
        ) {
            Log.e(TAG, "Saved drawing area is invalid; requesting new calibration.")
            return null
        }
        val rect =
            NormalizedRect(
                left.coerceIn(0f, 0.99f),
                top.coerceIn(0f, 0.99f),
                width.coerceIn(0.01f, 1f),
                height.coerceIn(0.01f, 1f),
            )
        Log.i(TAG, "Restored normalized drawing area for screen ${screenWidth}x$screenHeight: $rect")
        return rect
    }

    private fun saveArea(area: NormalizedRect, screenWidth: Int, screenHeight: Int) {
        val landscape = screenWidth >= screenHeight
        areaPreferences.edit()
            .putFloat(KEY_AREA_LEFT, area.left)
            .putFloat(KEY_AREA_TOP, area.top)
            .putFloat(KEY_AREA_WIDTH, area.width)
            .putFloat(KEY_AREA_HEIGHT, area.height)
            .putBoolean(KEY_AREA_LANDSCAPE, landscape)
            .putFloat(KEY_AREA_ASPECT, screenWidth.toFloat() / screenHeight)
            .apply()
        Log.i(TAG, "Persisted drawing area for ${screenWidth}x$screenHeight (landscape=$landscape).")
    }

    private fun beginDispatch() {
        if (!selectionState.isConfirmed) {
            updateOverlay(
                "حدّد مساحة لوحة الرسم بالإطار الأخضر أولًا.",
                "تحديد مساحة الرسم",
                ::beginAreaSelection,
            )
            return
        }
        if (!targetReady || activePackage != targetPackage) {
            Log.w(TAG, "Drawing start deferred until WePlay returns; confirmed area is retained.")
            updateOverlay(
                "عد إلى WePlay؛ المساحة المحددة محفوظة ولم يبدأ الرسم.",
                "ابدأ الرسم",
                ::beginDispatch,
            )
            return
        }
        val (screenWidth, screenHeight) = screenSize()
        val area =
            normalizedArea?.toScreenRect(screenWidth, screenHeight)
                ?: ScreenRect(
                    areaLeft.coerceIn(0, screenWidth - 1),
                    areaTop.coerceIn(0, screenHeight - 1),
                    areaWidth.coerceIn(1, screenWidth - areaLeft.coerceIn(0, screenWidth - 1)),
                    areaHeight.coerceIn(1, screenHeight - areaTop.coerceIn(0, screenHeight - 1)),
                )
        drawingTransform =
            DrawingGeometry.fit(
                sourceWidth = imageWidth,
                sourceHeight = imageHeight,
                area = area,
                screenWidth = screenWidth,
                screenHeight = screenHeight,
                sizeScale = sizeScale,
                horizontalOffset = horizontalOffset,
                verticalOffset = verticalOffset,
            )
        val bounds = drawingTransform!!.drawingBounds
        Log.i(
            TAG,
            "Drawing initialized: screen=${screenWidth}x$screenHeight, selectedArea=$area, " +
                "source=${imageWidth}x$imageHeight, draw=${bounds.width}x${bounds.height} " +
                "at (${bounds.left},${bounds.top}), size=$sizeScale, speed=$speed, strokes=$totalGestureCount",
        )
        waitingForTarget = false
        targetReady = false
        isDrawing = true
        handler.removeCallbacks(waitTimeout)
        updateOverlay(
            "حجم الرسم ${bounds.width.toInt()}×${bounds.height.toInt()} بكسل داخل الإطار.",
            "إيقاف الرسم",
            { stopDrawing("أوقف المستخدم الرسم.") },
        )
        val token = runToken
        handler.post { dispatchNext(token) }
    }

    private fun dispatchNext(token: Int) {
        if (token != runToken || !isDrawing) return
        if (activePackage != targetPackage) {
            stopDrawing("توقف الرسم لأن WePlay لم تعد في الواجهة.")
            return
        }
        val stroke = strokes.removeFirstOrNull()
        if (stroke == null) {
            stopDrawing(
                "أرسل Android $completedGestureCount من $totalGestureCount إيماءة. هذا لا يؤكد أن WePlay رسمها.",
            )
            return
        }
        if (stroke.points.size < 2) {
            handler.post { dispatchNext(token) }
            return
        }

        val transform = drawingTransform
        if (transform == null) {
            Log.e(TAG, "Cannot dispatch a stroke: drawing transform was not initialized.")
            stopDrawing("تعذر بدء الرسم: لم تُحسب إحداثيات المساحة.")
            return
        }
        val (screenWidth, screenHeight) = screenSize()
        if (screenWidth != transform.screenWidth || screenHeight != transform.screenHeight) {
            Log.w(
                TAG,
                "Display size changed during drawing: ${transform.screenWidth}x${transform.screenHeight} -> ${screenWidth}x$screenHeight",
            )
            stopDrawing("تغيّر اتجاه الشاشة أو حجمها. أعد تحديد المساحة قبل الرسم.")
            return
        }

        val path = Path()
        var length = 0f
        stroke.points.forEachIndexed { index, point ->
            val mapped = transform.map(point.x, point.y)
            if (index == 0) {
                path.moveTo(mapped.x, mapped.y)
            } else {
                val previous = transform.map(stroke.points[index - 1].x, stroke.points[index - 1].y)
                val dx = mapped.x - previous.x
                val dy = mapped.y - previous.y
                length += kotlin.math.sqrt(dx * dx + dy * dy)
                path.lineTo(mapped.x, mapped.y)
            }
        }
        val duration = (length / (0.55f * speed)).toLong().coerceIn(40L, 300L)
        dispatchedGestureCount++
        if (dispatchedGestureCount == 1 || dispatchedGestureCount % 50 == 0) {
            Log.d(
                TAG,
                "Dispatching gesture $dispatchedGestureCount/$totalGestureCount: " +
                    "points=${stroke.points.size}, lengthPx=$length, durationMs=$duration, " +
                    "bounds=${transform.drawingBounds}",
            )
        }
        val accepted =
            try {
                val gesture =
                    GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                        .build()
                dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (token == runToken && isDrawing) {
                            completedGestureCount++
                            if (completedGestureCount == 1 || completedGestureCount % 50 == 0) {
                                Log.d(
                                    TAG,
                                    "Android completed gesture $completedGestureCount/$totalGestureCount.",
                                )
                            }
                            if (completedGestureCount == 1 ||
                                completedGestureCount % 10 == 0 ||
                                completedGestureCount == totalGestureCount
                            ) {
                                updateOverlay(
                                    "إيماءات Android: $completedGestureCount/$totalGestureCount. هذا لا يؤكد الرسم في WePlay.",
                                    "إيقاف الرسم",
                                    { stopDrawing("أوقف المستخدم الرسم.") },
                                )
                            }
                            handler.postDelayed({ dispatchNext(token) }, 12L)
                        }
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (token == runToken && isDrawing) {
                            stopDrawing("ألغى Android إيماءة الرسم.")
                        }
                    }
                },
                handler,
                )
            } catch (error: Exception) {
                Log.e(TAG, "Android threw while dispatching gesture $dispatchedGestureCount.", error)
                stopDrawing("تعذر إرسال اللمسة: ${error.localizedMessage ?: "خطأ في خدمة Android"}")
                return
            }
        if (!accepted && token == runToken) {
            Log.e(TAG, "Android rejected gesture $dispatchedGestureCount.")
            stopDrawing("رفض Android إرسال الإيماءة. تحقق من إعدادات الخدمة.")
        }
    }

    fun stopDrawing(message: String?) {
        runToken++
        selectionState.reset()
        handler.removeCallbacks(waitTimeout)
        waitingForTarget = false
        targetReady = false
        isDrawing = false
        strokes.clear()
        targetPackage = null
        drawingTransform = null
        Log.i(TAG, "Session stopped: ${message ?: "no user-facing message"}")
        removeAreaOverlay()
        removeOverlay()
        if (!message.isNullOrBlank()) showToast(message)
    }

    private fun removeAreaOverlay() {
        val view = areaSelectionOverlay
        if (view != null) {
            try {
                windowManager?.removeView(view)
            } catch (error: Exception) {
                Log.w(TAG, "Selection frame was already detached or could not be removed.", error)
            }
        }
        areaSelectionOverlay = null
    }

    private fun showControlOverlay(status: String, buttonLabel: String, action: () -> Unit) {
        if (!overlayAttached) {
            val root =
                LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(9), dp(12), dp(9))
                    background =
                        GradientDrawable().apply {
                            setColor(Color.rgb(13, 27, 42))
                            cornerRadius = dp(14).toFloat()
                            setStroke(dp(1), Color.rgb(80, 224, 188))
                        }
                    elevation = dp(8).toFloat()
                }
            val statusText =
                TextView(this).apply {
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    textDirection = View.TEXT_DIRECTION_RTL
                }
            val button =
                Button(this).apply {
                    isAllCaps = false
                    textSize = 14f
                    setTextColor(Color.rgb(7, 17, 31))
                    background =
                        GradientDrawable().apply {
                            setColor(Color.rgb(80, 224, 188))
                            cornerRadius = dp(9).toFloat()
                        }
                    setPadding(dp(10), 0, dp(10), 0)
                    minHeight = dp(42)
                    setOnClickListener { onOverlayAction?.invoke() }
                }
            root.addView(statusText)
            root.addView(
                button,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(5) },
            )
            overlay = root
            overlayStatus = statusText
            overlayButton = button
            onOverlayAction = action
            val params =
                WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT,
                ).apply {
                    gravity = Gravity.TOP or Gravity.END
                    x = dp(12)
                    y = dp(34)
                }
            try {
                val manager = windowManager ?: error("WindowManager is unavailable")
                manager.addView(root, params)
                overlayAttached = true
            } catch (error: Exception) {
                Log.e(TAG, "Unable to attach the floating control window.", error)
                overlayAttached = false
                stopDrawing("تعذر عرض زر التحكم: ${error.localizedMessage ?: "خطأ نافذة Android"}")
                return
            }
        }
        updateOverlay(status, buttonLabel, action)
    }

    private var onOverlayAction: (() -> Unit)? = null

    private fun updateOverlay(status: String, buttonLabel: String, action: () -> Unit) {
        overlayStatus?.text = status
        overlayButton?.text = buttonLabel
        onOverlayAction = action
    }

    private fun removeOverlay() {
        val view = overlay
        if (view != null && overlayAttached) {
            try {
                windowManager?.removeView(view)
            } catch (error: Exception) {
                Log.w(TAG, "Floating control window was already detached or could not be removed.", error)
            }
        }
        overlay = null
        overlayStatus = null
        overlayButton = null
        onOverlayAction = null
        overlayAttached = false
    }

    private fun screenSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getRealMetrics(metrics)
        if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) {
            val fallback = resources.displayMetrics
            return fallback.widthPixels.coerceAtLeast(1) to fallback.heightPixels.coerceAtLeast(1)
        }
        return metrics.widthPixels.coerceAtLeast(1) to metrics.heightPixels.coerceAtLeast(1)
    }

    private fun showToast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        stopDrawing(null)
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "WePlayAutoDraw"
        private const val AREA_PREFERENCES = "weplay_autodraw_area"
        private const val KEY_AREA_LEFT = "left"
        private const val KEY_AREA_TOP = "top"
        private const val KEY_AREA_WIDTH = "width"
        private const val KEY_AREA_HEIGHT = "height"
        private const val KEY_AREA_LANDSCAPE = "landscape"
        private const val KEY_AREA_ASPECT = "screen_aspect"

        @Volatile
        var activeService: DrawAccessibilityService? = null
            private set
    }
}

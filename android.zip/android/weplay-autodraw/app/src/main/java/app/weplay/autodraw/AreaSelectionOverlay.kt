package app.weplay.autodraw

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.roundToInt

/** A movable, resizable touch frame used to match the drawing canvas on screen. */
internal class AreaSelectionOverlay(
    context: Context,
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val onBoundsChanged: (left: Int, top: Int, width: Int, height: Int) -> Unit,
    private val onConfirm: () -> Unit,
    private val onWindowFailure: (Exception) -> Unit,
) : View(context) {
    private val density = resources.displayMetrics.density
    private val borderPaint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(80, 224, 188)
            style = Paint.Style.STROKE
            strokeWidth = dp(3f)
        }
    private val fillPaint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(22, 80, 224, 188)
            style = Paint.Style.FILL
        }
    private val handlePaint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(80, 224, 188)
            style = Paint.Style.FILL
        }
    private val textPaint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = dp(14f)
            textAlign = Paint.Align.CENTER
            setShadowLayer(dp(3f), 0f, 0f, Color.BLACK)
        }
    private val confirmBackground =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(13, 27, 42)
            style = Paint.Style.FILL
        }
    private val confirmTextPaint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(80, 224, 188)
            textSize = dp(14f)
            textAlign = Paint.Align.CENTER
        }

    private var windowManager: WindowManager? = null
    private var windowParams: WindowManager.LayoutParams? = null
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var startWidth = 0
    private var startHeight = 0
    private var resizing = false
    private var confirming = false

    fun attach(manager: WindowManager, params: WindowManager.LayoutParams) {
        windowManager = manager
        windowParams = params
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val inset = dp(2f)
        canvas.drawRect(inset, inset, width - inset, height - inset, fillPaint)
        canvas.drawRect(inset, inset, width - inset, height - inset, borderPaint)
        canvas.drawText("حرّك الإطار", width / 2f, height / 2f - dp(5f), textPaint)
        canvas.drawText("اسحب الزاوية للحجم", width / 2f, height / 2f + dp(17f), textPaint)
        canvas.drawCircle(
            width - dp(15f),
            height - dp(15f),
            dp(11f),
            handlePaint,
        )
        val confirm = confirmRect()
        canvas.drawRoundRect(confirm, dp(8f), dp(8f), confirmBackground)
        canvas.drawText(
            "اعتماد المساحة",
            confirm.centerX(),
            confirm.centerY() + dp(5f),
            confirmTextPaint,
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val params = windowParams ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                confirming = confirmRect().contains(event.x, event.y)
                if (confirming) return true
                downRawX = event.rawX
                downRawY = event.rawY
                startX = params.x
                startY = params.y
                startWidth = params.width
                startHeight = params.height
                val handleEdge = dp(40f)
                resizing = event.x >= width - handleEdge && event.y >= height - handleEdge
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (confirming) return true
                val previousX = params.x
                val previousY = params.y
                val previousWidth = params.width
                val previousHeight = params.height
                val deltaX = (event.rawX - downRawX).roundToInt()
                val deltaY = (event.rawY - downRawY).roundToInt()
                if (resizing) {
                    val minimum = dp(180f).roundToInt()
                    params.width =
                        (startWidth + deltaX).coerceIn(
                            minimum,
                            (screenWidth - startX).coerceAtLeast(minimum),
                        )
                    params.height =
                        (startHeight + deltaY).coerceIn(
                            minimum,
                            (screenHeight - startY).coerceAtLeast(minimum),
                        )
                } else {
                    params.x = (startX + deltaX).coerceIn(0, (screenWidth - params.width).coerceAtLeast(0))
                    params.y = (startY + deltaY).coerceIn(0, (screenHeight - params.height).coerceAtLeast(0))
                }
                try {
                    val manager = windowManager ?: error("WindowManager is unavailable")
                    manager.updateViewLayout(this, params)
                } catch (error: Exception) {
                    params.x = previousX
                    params.y = previousY
                    params.width = previousWidth
                    params.height = previousHeight
                    onWindowFailure(error)
                    invalidate()
                    return true
                }
                onBoundsChanged(params.x, params.y, params.width, params.height)
                return true
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL,
            -> {
                if (confirming) {
                    val shouldConfirm =
                        event.actionMasked == MotionEvent.ACTION_UP &&
                            confirmRect().contains(event.x, event.y)
                    confirming = false
                    if (shouldConfirm) onConfirm()
                    return true
                }
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun dp(value: Float): Float = value * density

    private fun confirmRect() =
        android.graphics.RectF(
            dp(10f),
            dp(10f),
            dp(150f),
            dp(50f),
        )
}

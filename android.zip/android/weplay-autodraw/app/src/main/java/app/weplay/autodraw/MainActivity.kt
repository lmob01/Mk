package app.weplay.autodraw

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.widget.AdapterView
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.graphics.ImageDecoder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.view.accessibility.AccessibilityManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val controlPreferences: SharedPreferences by lazy {
        getSharedPreferences(CONTROL_PREFERENCES, MODE_PRIVATE)
    }
    private lateinit var faceDetector: FaceDetector
    private lateinit var preview: ImageView
    private lateinit var previewPlaceholder: TextView
    private lateinit var processingStatus: TextView
    private lateinit var targetStatus: TextView
    private lateinit var serviceStatus: TextView
    private lateinit var targetSpinner: Spinner
    private lateinit var consentCheck: CheckBox
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var chooseButton: Button

    private var targetApps: List<TargetApp> = emptyList()
    private var preparedBitmap: Bitmap? = null
    private var outputBitmap: Bitmap? = null
    private var faceContours: List<List<PointF>> = emptyList()
    private var strokes: List<DrawStroke> = emptyList()
    private var processVersion = 0
    private var thresholdProgress = 45
    private var sizeProgress = 65
    private var horizontalProgress = 50
    private var verticalProgress = 50
    private var speedProgress = 1

    private val backgroundColor = Color.rgb(7, 17, 31)
    private val cardBackground = Color.rgb(15, 30, 45)
    private val mutedText = Color.rgb(165, 183, 198)
    private val mint = Color.rgb(80, 224, 188)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreControlSettings()
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor

        faceDetector =
            FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                    .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                    .build(),
            )
        buildInterface()
        refreshWePlayTargets()
        refreshServiceStatus()
    }

    override fun onResume() {
        super.onResume()
        isInForeground = true
        if (::serviceStatus.isInitialized) refreshServiceStatus()
        if (::stopButton.isInitialized) {
            stopButton.isEnabled =
                DrawAccessibilityService.activeService?.hasActiveSession == true
        }
    }

    override fun onPause() {
        isInForeground = false
        super.onPause()
    }

    private fun buildInterface() {
        val scroll =
            ScrollView(this).apply {
                setBackgroundColor(backgroundColor)
                isFillViewport = true
                clipToPadding = false
            }
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener { view, insets ->
                val safe = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(dp(20) + safe.left, safe.top, dp(20) + safe.right, safe.bottom + dp(16))
                insets
            }
        } else {
            scroll.setPadding(dp(20), dp(14), dp(20), dp(20))
        }
        val content =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(0), dp(12), dp(0), dp(20))
            }
        scroll.addView(
            content,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
            ),
        )

        content.addView(
            text(
                "WePlay AutoDraw",
                27f,
                Color.WHITE,
                bold = true,
                direction = View.TEXT_DIRECTION_LTR,
            ),
            margin(bottom = 4),
        )
        content.addView(
            text(
                "حوّل صورة إلى خطوط سوداء على خلفية بيضاء، ثم راجع الرسم قبل نقله.",
                15f,
                mutedText,
            ),
            margin(bottom = 16),
        )

        val targetCard = card()
        targetCard.addView(text("التطبيق المستهدف", 17f, Color.WHITE, true), margin(bottom = 8))
        targetSpinner =
            Spinner(this).apply {
                contentDescription = "اختر تطبيق WePlay المثبّت"
                setPadding(dp(10), dp(4), dp(10), dp(4))
            }
        targetCard.addView(targetSpinner, margin(bottom = 7))
        targetStatus =
            text(
                "يبحث التطبيق عن نسخة WePlay المثبّتة في قائمة تطبيقات Android.",
                13f,
                mutedText,
            )
        targetCard.addView(targetStatus)
        content.addView(targetCard, margin(bottom = 14))

        val photoCard = card()
        photoCard.addView(text("الصورة والرسم", 17f, Color.WHITE, true), margin(bottom = 10))
        chooseButton = primaryButton("اختيار صورة من المعرض")
        chooseButton.setOnClickListener { choosePhoto() }
        photoCard.addView(chooseButton, matchWidth())

        val previewFrame =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                setBackgroundColor(Color.WHITE)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                minimumHeight = dp(210)
            }
        preview =
            ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = "معاينة الرسم الخطي الأسود والأبيض"
                visibility = View.GONE
            }
        previewPlaceholder =
            text("اختر صورة لعرض معاينتها هنا", 14f, Color.rgb(78, 94, 107)).apply {
                gravity = android.view.Gravity.CENTER
                setPadding(dp(14), dp(48), dp(14), dp(48))
            }
        previewFrame.addView(previewPlaceholder)
        previewFrame.addView(
            preview,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ),
        )
        val frameParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(12)
            bottomMargin = dp(6)
        }
        photoCard.addView(previewFrame, frameParams)
        processingStatus =
            text("لم تُختر صورة بعد.", 13f, mutedText).apply {
                gravity = android.view.Gravity.CENTER
            }
        photoCard.addView(processingStatus, margin(top = 5, bottom = 5))
        content.addView(photoCard, margin(bottom = 14))

        val controlCard = card()
        controlCard.addView(text("ضبط الرسم داخل المنطقة", 17f, Color.WHITE, true), margin(bottom = 5))
        controlCard.addView(
            text(
                "بعد فتح لوحة الرسم في WePlay، حرّك الإطار الأخضر ليغطي مساحة الرسم واضبط حجمه من الزاوية.",
                13f,
                mutedText,
            ),
            margin(bottom = 5),
        )
        addSlider(
            controlCard,
            "وضوح الخطوط",
            thresholdProgress,
            125,
            { value -> "عتبة $value" },
        ) { progress ->
            thresholdProgress = progress
            persistControlSetting(KEY_THRESHOLD, progress)
            scheduleRender()
        }
        addSlider(controlCard, "حجم الرسم داخل الإطار", sizeProgress, 65, { value -> "${35 + value}%" }) { progress ->
            sizeProgress = progress
            persistControlSetting(KEY_SIZE, progress)
        }
        addSlider(
            controlCard,
            "الإزاحة الأفقية داخل الإطار",
            horizontalProgress,
            100,
            { value -> "${((value - 50) * 0.8f).roundToInt()}%" },
        ) { progress ->
            horizontalProgress = progress
            persistControlSetting(KEY_HORIZONTAL, progress)
        }
        addSlider(
            controlCard,
            "الإزاحة العمودية داخل الإطار",
            verticalProgress,
            100,
            { value -> "${((value - 50) * 0.8f).roundToInt()}%" },
        ) { progress ->
            verticalProgress = progress
            persistControlSetting(KEY_VERTICAL, progress)
        }
        addSlider(controlCard, "سرعة الرسم", speedProgress, 4, { value -> "${value + 1}×" }) { progress ->
            speedProgress = progress
            persistControlSetting(KEY_SPEED, progress)
        }
        content.addView(controlCard, margin(bottom = 14))

        val accessCard = card()
        accessCard.addView(text("تنفيذ الرسم", 17f, Color.WHITE, true), margin(bottom = 6))
        accessCard.addView(
            text(
                "يتطلب ذلك تفعيل خدمة إمكانية الوصول من إعدادات Android. بعد الموافقة وفتح صفحة الرسم في WePlay، اضغط «تحديد مساحة الرسم» واسحب الإطار الأخضر فوق اللوحة، ثم اعتمده لبدء الرسم.",
                14f,
                mutedText,
            ),
            margin(bottom = 9),
        )
        serviceStatus = text("الخدمة غير مفعّلة.", 13f, mutedText)
        accessCard.addView(serviceStatus, margin(bottom = 8))
        val serviceSettingsButton = secondaryButton("إعداد خدمة إمكانية الوصول")
        serviceSettingsButton.setOnClickListener { showAccessibilityDisclosure(openSettings = true) }
        accessCard.addView(serviceSettingsButton, matchWidth())
        consentCheck =
            CheckBox(this).apply {
                text =
                    "أوافق على إرسال لمسات الرسم إلى WePlay بعد مراجعة قواعده."
                setTextColor(Color.WHITE)
                textSize = 14f
                buttonTintList =
                    android.content.res.ColorStateList.valueOf(mint)
                contentDescription = "الموافقة الصريحة على إرسال لمسات الرسم إلى WePlay"
            }
        accessCard.addView(consentCheck, margin(top = 5))
        content.addView(accessCard, margin(bottom = 14))

        val notice =
            text(
                "تنبيه: قد تمنع شروط WePlay أو سياسات متجر التطبيقات الأتمتة. راجع القواعد قبل الاستخدام. لم يُختبر استقبال الرسم داخل WePlay على جهاز حقيقي؛ لا يوجد ضمان للتوافق.",
                13f,
                Color.rgb(244, 198, 123),
            )
        content.addView(notice, margin(bottom = 12))

        startButton = primaryButton("إعداد الرسم في WePlay")
        startButton.isEnabled = false
        startButton.setOnClickListener { beginUserFlow() }
        content.addView(startButton, margin(bottom = 8))

        stopButton = secondaryButton("إيقاف فوري")
        stopButton.isEnabled = false
        stopButton.setOnClickListener {
            DrawAccessibilityService.activeService?.stopDrawing("أوقف المستخدم الرسم.")
            stopButton.isEnabled = false
            processingStatus.text = "تم إيقاف الرسم."
            updateStartButton()
        }
        content.addView(stopButton, margin(bottom = 15))
        content.addView(
            text(
                "يوقف زر الإيقاف إرسال المسارات التالية فورًا. قد تكتمل اللمسة الحالية خلال 300 مللي ثانية كحد أقصى.",
                12f,
                mutedText,
            ),
            margin(bottom = 5),
        )

        setContentView(scroll)
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        initial: Int,
        maxValue: Int,
        valueLabel: (Int) -> String,
        onChange: (Int) -> Unit,
    ) {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(1))
        }
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val titleView = text(title, 14f, Color.WHITE)
        heading.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
        val valueView = text(valueLabel(initial), 13f, mint, true).apply {
            gravity = android.view.Gravity.CENTER
        }
        heading.addView(valueView)
        wrapper.addView(heading)

        val seekBar = SeekBar(this).apply {
            max = maxValue
            progress = initial.coerceIn(0, maxValue)
            contentDescription = title
            progressTintList = android.content.res.ColorStateList.valueOf(mint)
            thumbTintList = android.content.res.ColorStateList.valueOf(mint)
            progressBackgroundTintList =
                android.content.res.ColorStateList.valueOf(Color.rgb(47, 67, 83))
        }
        seekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    valueView.text = valueLabel(progress)
                    if (fromUser) onChange(progress)
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            },
        )
        wrapper.addView(seekBar)
        parent.addView(wrapper)
    }

    private fun restoreControlSettings() {
        thresholdProgress = controlPreferences.getInt(KEY_THRESHOLD, 45).coerceIn(0, 125)
        sizeProgress = controlPreferences.getInt(KEY_SIZE, 65).coerceIn(0, 65)
        horizontalProgress = controlPreferences.getInt(KEY_HORIZONTAL, 50).coerceIn(0, 100)
        verticalProgress = controlPreferences.getInt(KEY_VERTICAL, 50).coerceIn(0, 100)
        speedProgress = controlPreferences.getInt(KEY_SPEED, 1).coerceIn(0, 4)
    }

    private fun persistControlSetting(key: String, progress: Int) {
        controlPreferences.edit().putInt(key, progress).apply()
    }

    private fun choosePhoto() {
        val intent =
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_IMAGE)
    }

    @Deprecated("Uses ACTION_OPEN_DOCUMENT for the Android 9 compatible system photo picker.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_IMAGE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val takeFlags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
            contentResolver.takePersistableUriPermission(uri, takeFlags)
        } catch (_: SecurityException) {
            // The current read grant is enough for this processing session.
        }
        loadAndProcess(uri)
    }

    private fun loadAndProcess(uri: android.net.Uri) {
        processingStatus.text = "جارٍ تحميل الصورة واستخراج الخطوط…"
        chooseButton.isEnabled = false
        startButton.isEnabled = false
        val version = ++processVersion
        worker.execute {
            var decodedSource: Bitmap? = null
            try {
                val source =
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) {
                            decoder,
                            info,
                            _,
                        ->
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val maxSize = EdgeProcessor.MAX_EDGE.toFloat()
                        val ratio = minOf(1f, maxSize / maxOf(info.size.width, info.size.height))
                        if (ratio < 1f) {
                            decoder.setTargetSize(
                                (info.size.width * ratio).roundToInt().coerceAtLeast(1),
                                (info.size.height * ratio).roundToInt().coerceAtLeast(1),
                            )
                        }
                    }
                decodedSource = source
                val prepared = EdgeProcessor.prepare(source)
                Log.i(
                    TAG,
                    "Image prepared: decoded=${source.width}x${source.height}, " +
                        "working=${prepared.width}x${prepared.height}, maxEdge=${EdgeProcessor.MAX_EDGE}",
                )
                if (source !== prepared && !source.isRecycled) source.recycle()
                decodedSource = null
                runOnUiThread {
                    if (version != processVersion) {
                        prepared.recycle()
                        return@runOnUiThread
                    }
                    preparedBitmap?.recycle()
                    outputBitmap?.recycle()
                    preparedBitmap = prepared
                    outputBitmap = null
                    faceContours = emptyList()
                    strokes = emptyList()
                    preview.visibility = View.GONE
                    previewPlaceholder.visibility = View.GONE
                    preview.setImageDrawable(null)
                    detectFaceContours(version)
                }
            } catch (error: Exception) {
                decodedSource?.takeIf { !it.isRecycled }?.recycle()
                runOnUiThread {
                    if (version == processVersion) {
                        chooseButton.isEnabled = true
                        processingStatus.text = "تعذر فتح الصورة: ${error.localizedMessage ?: "صيغة غير مدعومة"}"
                        Log.e(TAG, "Failed to decode or prepare the selected image.", error)
                        updateStartButton()
                    }
                }
            }
        }
    }

    private fun detectFaceContours(version: Int) {
        val prepared = preparedBitmap ?: return
        processingStatus.text = "جارٍ تحليل الصورة والوجه…"
        val image = InputImage.fromBitmap(prepared, 0)
        faceDetector.process(image)
            .addOnSuccessListener { faces ->
                if (version != processVersion) return@addOnSuccessListener
                faceContours =
                    faces.flatMap { face ->
                        face.allContours.mapNotNull { contour ->
                            contour.points
                                .takeIf { points -> points.size >= 2 }
                                ?.map { point -> PointF(point.x, point.y) }
                        }
                    }
                renderCurrentImage(version, faces.size)
            }
            .addOnFailureListener { error ->
                if (version == processVersion) {
                    Log.w(TAG, "Face detection failed; continuing with image edges only.", error)
                    faceContours = emptyList()
                    renderCurrentImage(version, null)
                }
            }
    }

    private fun scheduleRender() {
        val version = processVersion
        mainHandler.removeCallbacksAndMessages(RENDER_TOKEN)
        mainHandler.postAtTime(
            { renderCurrentImage(version, null) },
            RENDER_TOKEN,
            android.os.SystemClock.uptimeMillis() + 180L,
        )
    }

    private fun renderCurrentImage(version: Int, faceCount: Int?) {
        val prepared = preparedBitmap ?: return
        val contours = faceContours.map { line -> line.map { PointF(it.x, it.y) } }
        val threshold = 35 + thresholdProgress * 2
        processingStatus.text = "جارٍ إنشاء معاينة ثنائية اللون…"
        startButton.isEnabled = false
        worker.execute {
            var renderedBitmap: Bitmap? = null
            try {
                val result = EdgeProcessor.render(prepared, threshold, contours)
                renderedBitmap = result
                val extracted = StrokeTracer.extract(result)
                    Log.i(
                        TAG,
                        "Line rendering complete: ${result.width}x${result.height}, threshold=$threshold, " +
                            "faceContours=${contours.size}, strokes=${extracted.size}",
                    )
                runOnUiThread {
                    if (version != processVersion) {
                        result.recycle()
                        return@runOnUiThread
                    }
                    outputBitmap?.recycle()
                    outputBitmap = result
                    strokes = extracted
                    preview.setImageBitmap(result)
                    preview.visibility = View.VISIBLE
                    previewPlaceholder.visibility = View.GONE
                    chooseButton.isEnabled = true
                    val facesMessage =
                        when (faceCount) {
                            null -> "تعذّر كشف الوجه؛ ظهرت الخطوط العامة فقط."
                            0 -> "لم يُكتشف وجه؛ استُخرجت حدود الصورة فقط."
                            else -> "أُضيفت تفاصيل $faceCount وجهًا إلى حدود الصورة."
                        }
                    processingStatus.text =
                        "معاينة أبيض وأسود نقية · ${extracted.size} مسارًا · $facesMessage"
                    updateStartButton()
                }
            } catch (error: Exception) {
                runOnUiThread {
                    if (version == processVersion) {
                        chooseButton.isEnabled = true
                        processingStatus.text =
                            "تعذرت معالجة الصورة: ${error.localizedMessage ?: "خطأ غير معروف"}"
                        Log.e(TAG, "Failed to render or trace the image.", error)
                        updateStartButton()
                    }
                }
                renderedBitmap?.takeIf { !it.isRecycled }?.recycle()
            }
        }
    }

    private fun refreshWePlayTargets() {
        val launcherIntent =
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities =
            if (Build.VERSION.SDK_INT >= 33) {
                packageManager.queryIntentActivities(
                    launcherIntent,
                    PackageManager.ResolveInfoFlags.of(0L),
                )
            } else {
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(launcherIntent, 0)
            }
        targetApps =
            activities
                .mapNotNull { info ->
                    val label = info.loadLabel(packageManager)?.toString().orEmpty()
                    if (label.contains("weplay", ignoreCase = true)) {
                        TargetApp(label, info.activityInfo.packageName)
                    } else {
                        null
                    }
                }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }

        targetSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                targetApps.map { "${it.label} · ${it.packageName}" },
            ).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
        val savedTarget = controlPreferences.getString(KEY_TARGET_PACKAGE, null)
        val savedTargetIndex = targetApps.indexOfFirst { it.packageName == savedTarget }
        if (savedTargetIndex >= 0) targetSpinner.setSelection(savedTargetIndex)
        targetSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long,
                ) {
                    targetApps.getOrNull(position)?.let { app ->
                        controlPreferences.edit().putString(KEY_TARGET_PACKAGE, app.packageName).apply()
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        targetStatus.text =
            if (targetApps.isEmpty()) {
                "لم يُعثر على تطبيق مثبت باسم WePlay. ثبّته ثم أعد فتح التطبيق."
            } else {
                "اختر النسخة المثبتة. لن تُرسل اللمسات إلا عندما تكون حزمة WePlay المختارة في الواجهة."
            }
        updateStartButton()
    }

    private fun beginUserFlow() {
        if (strokes.isEmpty()) {
            showToast("اختر صورة وانتظر اكتمال المعاينة أولًا.")
            return
        }
        if (targetApps.isEmpty()) {
            showToast("لم يتم العثور على تطبيق WePlay مثبت.")
            return
        }
        if (!consentCheck.isChecked) {
            showToast("أكّد موافقتك بعد مراجعة التنبيه قبل المتابعة.")
            return
        }
        if (!isAccessibilityServiceEnabled()) {
            showAccessibilityDisclosure(openSettings = true)
            return
        }
        val service = DrawAccessibilityService.activeService
        if (service == null) {
            showToast("الخدمة مفعّلة في Android لكنها لم تبدأ بعد. ارجع إلى التطبيق وحاول مجددًا.")
            return
        }
        val target = targetApps.getOrNull(targetSpinner.selectedItemPosition) ?: return
        AlertDialog.Builder(this)
            .setTitle("تأكيد بدء الرسم")
            .setMessage(
                "سترسل الخدمة مسارات لمس مرئية فقط إلى «${target.label}» بعد فتح صفحة الرسم، وتحديد مساحة اللوحة بالإطار الأخضر، ثم ضغط «ابدأ الرسم». لا تقرأ الخدمة محتوى الشاشة ولا تسجّله. توافق WePlay مع هذه اللمسات غير مختبر. تأكد من أن قواعد التطبيق تسمح بذلك.",
            )
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("أوافق، تابع") { _, _ ->
                val bitmap = outputBitmap ?: return@setPositiveButton
                service.startDrawing(
                    sourceStrokes = strokes,
                    selectedPackage = target.packageName,
                    sourceWidth = bitmap.width,
                    sourceHeight = bitmap.height,
                    scale = (35 + sizeProgress) / 100f,
                    xOffset = ((horizontalProgress - 50) / 50f) * 0.4f,
                    yOffset = ((verticalProgress - 50) / 50f) * 0.4f,
                    speedMultiplier = (1 + speedProgress).toFloat(),
                )
                stopButton.isEnabled = true
                processingStatus.text = "بانتظار فتح WePlay ثم تحديد مساحة لوحة الرسم."
                updateStartButton()
            }
            .show()
    }

    private fun showAccessibilityDisclosure(openSettings: Boolean) {
        AlertDialog.Builder(this)
            .setTitle("خدمة إمكانية الوصول")
            .setMessage(
                "تحتاج الميزة إلى خدمة Android Accessibility Service لإرسال مسارات اللمس. سيعرض Android شاشة إعدادات الخدمة، ويجب عليك تفعيل «WePlay AutoDraw» بنفسك. لا تقرأ الخدمة محتوى الشاشة ولا تسجله؛ تستقبل فقط اسم الحزمة النشطة للتحقق من أن WePlay المختار هو المفتوح. يمكنك إيقاف الرسم من الزر العائم أو من التطبيق. قد تمنع قواعد WePlay أو سياسات المتجر هذا الاستخدام.",
            )
            .setNegativeButton("ليس الآن", null)
            .setPositiveButton(if (openSettings) "فتح إعدادات Android" else "حسنًا") { _, _ ->
                if (openSettings) {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            .show()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val enabled =
            Settings.Secure.getInt(
                contentResolver,
                Settings.Secure.ACCESSIBILITY_ENABLED,
                0,
            ) == 1
        if (!enabled) return false
        val expected =
            ComponentName(this, DrawAccessibilityService::class.java).flattenToString()
        val active =
            Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            )
                ?: return false
        return active.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun refreshServiceStatus() {
        val enabled = isAccessibilityServiceEnabled()
        serviceStatus.text =
            when {
                !enabled -> "الخدمة غير مفعّلة في إعدادات Android."
                DrawAccessibilityService.activeService == null ->
                    "الخدمة مفعّلة؛ جارٍ انتظار اتصال Android."
                else -> "الخدمة مفعّلة. يبدأ الرسم بعد موافقتك وفتح WePlay."
            }
        updateStartButton()
    }

    private fun updateStartButton() {
        if (!::startButton.isInitialized) return
        startButton.isEnabled =
            strokes.isNotEmpty() &&
                targetApps.isNotEmpty() &&
                DrawAccessibilityService.activeService?.hasActiveSession != true &&
                !processingStatus.text.toString().startsWith("جارٍ")
        startButton.text = if (strokes.isEmpty()) "ابدأ" else "إعداد الرسم في WePlay"
    }

    private fun card(): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background =
                GradientDrawable().apply {
                    setColor(cardBackground)
                    cornerRadius = dp(18).toFloat()
                }
        }

    private fun text(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false,
        direction: Int = View.TEXT_DIRECTION_RTL,
    ): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            textDirection = direction
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setLineSpacing(dp(2).toFloat(), 1f)
        }

    private fun primaryButton(label: String): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(backgroundColor)
            background =
                GradientDrawable().apply {
                    setColor(mint)
                    cornerRadius = dp(13).toFloat()
                }
            minHeight = dp(52)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }

    private fun secondaryButton(label: String): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background =
                GradientDrawable().apply {
                    setColor(Color.rgb(34, 54, 71))
                    cornerRadius = dp(13).toFloat()
                    setStroke(dp(1), Color.rgb(69, 92, 109))
                }
            minHeight = dp(48)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        }

    private fun margin(
        top: Int = 0,
        bottom: Int = 0,
    ): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun matchWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2)

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        isInForeground = false
        processVersion++
        mainHandler.removeCallbacksAndMessages(RENDER_TOKEN)
        worker.shutdown()
        faceDetector.close()
        // A queued image task may still be reading these bitmaps. Let its references
        // finish naturally instead of recycling memory underneath the worker.
        preparedBitmap = null
        outputBitmap = null
        super.onDestroy()
    }

    private data class TargetApp(val label: String, val packageName: String)

    companion object {
        private const val TAG = "WePlayAutoDraw"
        private const val CONTROL_PREFERENCES = "weplay_autodraw_controls"
        private const val KEY_THRESHOLD = "threshold_progress"
        private const val KEY_SIZE = "size_progress"
        private const val KEY_HORIZONTAL = "horizontal_progress"
        private const val KEY_VERTICAL = "vertical_progress"
        private const val KEY_SPEED = "speed_progress"
        private const val KEY_TARGET_PACKAGE = "target_package"
        private const val REQUEST_IMAGE = 4121
        private val RENDER_TOKEN = Any()

        @Volatile
        var isInForeground = false
            private set
    }
}

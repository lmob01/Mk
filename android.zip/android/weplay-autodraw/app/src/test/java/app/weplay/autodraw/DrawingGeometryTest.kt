package app.weplay.autodraw

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DrawingGeometryTest {
    @Test
    fun fittingPreservesAspectRatioAndCentersInsideSelectedArea() {
        val area = ScreenRect(left = 100, top = 200, width = 1000, height = 500)

        val transform =
            DrawingGeometry.fit(
                sourceWidth = 720,
                sourceHeight = 720,
                area = area,
                screenWidth = 1200,
                screenHeight = 900,
                sizeScale = 1f,
                horizontalOffset = 0f,
                verticalOffset = 0f,
            )

        assertEquals(500f, transform.drawingBounds.width, 0.01f)
        assertEquals(500f, transform.drawingBounds.height, 0.01f)
        assertEquals(350f, transform.drawingBounds.left, 0.01f)
        assertEquals(200f, transform.drawingBounds.top, 0.01f)
        val topLeft = transform.map(0f, 0f)
        assertEquals(350f, topLeft.x, 0.01f)
        assertEquals(200f, topLeft.y, 0.01f)
    }

    @Test
    fun sizeAndOffsetsChangeOnlyTheFitWithinArea() {
        val area = ScreenRect(left = 50, top = 100, width = 800, height = 600)
        val small =
            DrawingGeometry.fit(
                1600, 900, area, 1000, 900,
                sizeScale = 0.5f,
                horizontalOffset = 0.4f,
                verticalOffset = -0.4f,
            )
        val full =
            DrawingGeometry.fit(
                1600, 900, area, 1000, 900,
                sizeScale = 1f,
                horizontalOffset = 0f,
                verticalOffset = 0f,
            )

        assertEquals(full.drawingBounds.width * 0.5f, small.drawingBounds.width, 0.01f)
        assertEquals(full.drawingBounds.height * 0.5f, small.drawingBounds.height, 0.01f)
        assertTrue(small.drawingBounds.left >= area.left)
        assertTrue(small.drawingBounds.top >= area.top)
        assertTrue(small.drawingBounds.left + small.drawingBounds.width <= area.left + area.width)
        assertTrue(small.drawingBounds.top + small.drawingBounds.height <= area.top + area.height)
    }

    @Test
    fun normalizedSelectionSurvivesScreenResolutionChanges() {
        val normalized =
            NormalizedRect.fromScreenRect(
                ScreenRect(left = 100, top = 150, width = 800, height = 500),
                screenWidth = 1000,
                screenHeight = 1000,
            )

        assertEquals(
            ScreenRect(left = 200, top = 150, width = 1600, height = 500),
            normalized.toScreenRect(screenWidth = 2000, screenHeight = 1000),
        )
    }

    @Test
    fun mappedPointsStayWithinSelectedPixels() {
        val area = ScreenRect(left = 10, top = 20, width = 100, height = 80)
        val transform = DrawingGeometry.fit(16, 9, area, 200, 150, 1f, 0.4f, -0.4f)

        val leftTop = transform.map(-1f, -1f)
        val rightBottom = transform.map(2f, 2f)
        assertEquals(10f, leftTop.x, 0f)
        assertTrue(leftTop.y >= 20f)
        assertTrue(rightBottom.x <= 109f)
        assertTrue(rightBottom.y <= 99f)
    }
}

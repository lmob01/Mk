package app.weplay.autodraw

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AreaSelectionStateTest {
    @Test
    fun confirmationWaitsForTargetWithoutDiscardingSelection() {
        val state = AreaSelectionState()
        val token = state.begin()

        assertEquals(
            AreaSelectionState.Confirmation.WAIT_FOR_TARGET,
            state.confirm(token, targetIsForeground = false),
        )
        assertTrue(state.isSelecting)
        assertFalse(state.isConfirmed)

        assertEquals(
            AreaSelectionState.Confirmation.CONFIRMED,
            state.confirm(token, targetIsForeground = true),
        )
        assertFalse(state.isSelecting)
        assertTrue(state.isConfirmed)
    }

    @Test
    fun duplicateConfirmationIsIdempotentAndOldTokensCannotChangeState() {
        val state = AreaSelectionState()
        val firstToken = state.begin()
        assertEquals(
            AreaSelectionState.Confirmation.CONFIRMED,
            state.confirm(firstToken, targetIsForeground = true),
        )
        assertEquals(
            AreaSelectionState.Confirmation.ALREADY_CONFIRMED,
            state.confirm(firstToken, targetIsForeground = true),
        )

        val secondToken = state.begin()
        assertEquals(
            AreaSelectionState.Confirmation.STALE,
            state.confirm(firstToken, targetIsForeground = true),
        )
        assertTrue(state.isSelecting)
        assertFalse(state.isConfirmed)
        assertEquals(
            AreaSelectionState.Confirmation.CONFIRMED,
            state.confirm(secondToken, targetIsForeground = true),
        )
    }
}

# WePlay AutoDraw

Native Android app written in Kotlin. It turns a gallery image into a strict
black-and-white edge drawing, adds ML Kit face contours, and can send the
resulting paths through Android Accessibility Service after explicit opt-in.

## Requirements

- JDK 17 or newer
- Android SDK Platform 35 and Build Tools 35.0.0
- Android Gradle Plugin 8.7.3 / Gradle 8.9 (the Gradle wrapper is included)

The app supports Android 9 (API 28) and newer.

## Build a debug APK

From this directory:

```sh
./gradlew copyDebugApk
```

The installable debug APK is copied to `../../generated-artifacts/WePlay-AutoDraw-debug.apk`.
Gradle also retains the original at `app/build/outputs/apk/debug/app-debug.apk`.

## Using the drawing service

1. Select an installed app whose launcher name contains “WePlay”.
2. Choose an image and review its black-and-white preview.
3. Adjust line threshold, size, position within the selected area, and speed.
4. Check the consent box, review the disclosure, and enable the service yourself
   in Android Accessibility settings.
5. Start setup, open WePlay, and navigate to its drawing screen. Press
   **Select drawing area** in the floating control.
6. Drag the translucent green frame over the drawing canvas. Drag its lower-right
   corner to resize it, then tap **Confirm area** inside the frame.
7. Press **Start drawing** in the floating control. Its counter shows gestures
   Android completed; it does not prove WePlay accepted or displayed them.
8. Use the floating **Stop drawing** control or return to this app and press
   **Immediate stop**.

The service listens only for window changes and checks the active app's package
name. It does not retrieve window contents, record the screen, or send image data
to a server. It stops if the selected app leaves the foreground. Android may
finish the current gesture (at most 300 ms) after stop is pressed, but no later
strokes are queued.

Use only if WePlay's current rules allow this kind of automation. A previous
real-device attempt showed Android gestures completing but no visible drawing in
WePlay. Android gesture completion does not prove that WePlay accepted or drew
them; canvas compatibility remains unconfirmed.

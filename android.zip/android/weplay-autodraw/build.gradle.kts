plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}

tasks.register<Copy>("copyDebugApk") {
    group = "build"
    description = "Build the debug APK and copy it to the workspace output folder."
    dependsOn(":app:assembleDebug")
    from(layout.projectDirectory.file("app/build/outputs/apk/debug/app-debug.apk"))
    into(rootProject.projectDir.resolve("../../generated-artifacts"))
    rename { "WePlay-AutoDraw-debug.apk" }
}
